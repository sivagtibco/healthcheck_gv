package main

import (
	_ "github.com/project-flogo/contrib/activity/rest"
	_ "github.com/project-flogo/contrib/activity/actreturn"
	_ "github.com/project-flogo/flow"
	_ "github.com/project-flogo/contrib/trigger/rest"
)
