// Do not change this file, it has been generated using flogo-cli
// If you change it and rebuild the application your changes might get lost
package main

// embedded flogo app descriptor file
const flogoJSON string = `{
  "name": "healthcheckgvapp",
  "type": "flogo:app",
  "version": "0.0.1",
  "description": "",
  "appModel": "1.1.0",
  "imports": [
    "github.com/project-flogo/contrib/activity/actreturn",
    "github.com/project-flogo/contrib/activity/rest",
    "github.com/project-flogo/contrib/trigger/rest",
    "github.com/project-flogo/flow"
  ],
  "properties": [
    {
      "name": "port",
      "type": "string",
      "value": "8002"
    }
  ],
  "triggers": [
    {
      "id": "receive_http_message",
      "ref": "#rest",
      "settings": {
        "port": "=$property[port]"
      },
      "handlers": [
        {
          "settings": {
            "method": "GET",
            "path": "/health"
          },
          "actions": [
            {
              "ref": "#flow",
              "settings": {
                "flowURI": "res://flow:health_check"
              },
              "output": {
                "code": "=$.statuscode",
                "data": "=$.message"
              }
            }
          ]
        }
      ]
    }
  ],
  "resources": [
    {
      "id": "flow:health_check",
      "data": {
        "name": "HealthCheck",
        "metadata": {
          "output": [
            {
              "name": "statuscode",
              "type": "integer"
            },
            {
              "name": "message",
              "type": "string"
            }
          ]
        },
        "tasks": [
          {
            "id": "rest_2",
            "name": "REST Invoke",
            "description": "Invokes a REST Service",
            "activity": {
              "ref": "#rest",
              "settings": {
                "uri": "http://billpay-ilab02-tmi-green.dev.px-npe01.cf.t-mobile.com/healthcheck/",
                "skipSSLVerify": true,
                "method": "GET"
              }
            }
          },
          {
            "id": "actreturn_3",
            "name": "Return",
            "description": "Return Activity",
            "activity": {
              "ref": "#actreturn",
              "settings": {
                "mappings": {
                  "message": "=$activity[rest_2].data",
                  "statuscode": "=$activity[rest_2].status"
                }
              }
            }
          }
        ],
        "links": [
          {
            "from": "rest_2",
            "to": "actreturn_3"
          }
        ]
      }
    }
  ]
}`

func init () {
	cfgJson = flogoJSON
}
